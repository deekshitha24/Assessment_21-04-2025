create table students(
id serial primary key,
name varchar(30) not null,
email varchar(50) unique,
age integer,
marks decimal
);

insert into students(name, email, age, marks)
values('Alice','alicedb@gmail.com',21,90),
	('Bob','bobkumar@gmail.com',25,70),
	('Charlie','charlie@gmail.com',18,50),
	('David','davidmann@gmail.com',15,65),
	('Eve','evefrae@gmail.com',21,35);

select * from students;

-- Fetch student details where age > 21.
select * from students where age > 21;

-- Update the email of the student with id = 5 to 'rahul@gmail.com'.
update students set email='rahul@gmail.com' where id=5;

--Delete all students with age < 18
delete from students where age <18;

--Find the second highest score student details
select marks from students limit 1 offset 1 ;


--2. 
create table student(
id serial,
name varchar(30),
age integer
);
insert into student(name,age)
	values('Rahul',22),
		('Priya',21),
		('Akash',23);
select * from student;

create table courses(
course_id integer,
student_id integer,
course_name varchar(20)
);
insert into courses(course_id,student_id,course_name)
	values(101,1,'Java'),
		(102,2,'Python'),
		(103,1,'SQL');
select * from courses;

--Write a query to display student names and their enrolled course names
select s.name,c.course_name from student s inner join courses c on s.id = c.student_id; 